require File.expand_path(File.join(File.dirname(__FILE__), "..", "..", "vendor", "plugins", "lre_master", "test", "user_experience_test_helper"))
include UserExperienceTestHelper

#
# This is a set of quick and dirty tests snuck into a 
# department that was against rails testing.  It was
# hooked up to run after a deployment on production 
# data, and simply verified the following:
#
#   1) the site responded with 200's on all main GET urls 
#   2) memory consumption didn't go over 70MB per mongrel
#   3) each page responded in less than 2 seconds
#
# If anything failed, the developer was prompted whether they
# wanted to rollback the deployment or let it stand.  
#
# It was useful and easy enough to maintain that we later
# added a number of traditional unit and functional tests.
#
describe "GET" do
  ['/',
   '/about',
   '/about/contact',
   '/about/honors_and_recognition',
   '/about/our_company',
   '/about/our_team',
   '/agents/our_team',
   '/advantages',
   '/advantages/for_buyers',
   '/advantages/for_sellers',
   '/advantages/affiliations',
   '/advantages/finance',
   '/communities',
   '/innercircle/show_forgot_password',
   '/innercircle/login',
   '/innercircle/sign_up',
   '/listings',
   '/listings/commercial_listings',
   '/listings/developments',
   '/listings/global_property_search',
   '/listings/miami_luxury',
   '/listings/search',
   '/luxury_communities',
   '/luxury_lifestyle_blog',
   '/luxury_properties',
   '/miami_living',
   '/miami_living/black_book',
   '/miami_living/miami_news',
   '/miami_living/relocating_to_miami',
   '/miami_living/state_of_the_market',
   '/mortgage_calculator',
   '/press_releases',
   '/press_releases/list',
   '/the_ross_report'
  ].each do |url|
    test_for_speed_and_errors url
  end

  describe "(enumerable tests)" do
    SUBS_LIMIT = 10

    describe "(agent profiles)" do
      AgentProfile.find!(:all, :select => "id, token").each do |profile|
        test_for_speed_and_errors "/about/our_team/#{profile.token}"
      end
    end

    describe "(luxury lifestyle blogs)" do
      ArticleGroup.find_by_token!("luxury_lifestyle_blog").articles.each do |article|
        test_for_speed_and_errors "/luxury_lifestyle_blog/#{article.token}"
      end
    end

    describe "(relocating to miami articles)" do
      ArticleGroup.find_by_token!("miami_living_relocating").articles.each do |article|
        test_for_speed_and_errors "/miami_living/relocating_to_miami/#{article.token}"
      end
    end

    describe "(miami news channels)" do
      FirmLinkCategory.find_by_name!("RSS Feeds").assets.each do |news_channel|
        test_for_speed_and_errors "/miami_living/miami_news/#{news_channel.id}"
      end
    end

    describe "(press release articles)" do
      ArticleGroup.find_by_token!("about_press").articles.each do |article|
        test_for_speed_and_errors "/press_releases/#{article.token}"
      end
    end

    describe "(properties)" do
      Property.find!(:all, :select => :id, :limit => PROPERTIES_LIMIT, :order => "RAND()").each do |property|
        test_for_speed_and_errors "/listings/#{property.id}"
        test_for_speed_and_errors "/listings/#{property.id}.pdf"
        test_for_speed_and_errors "/listings/email_a_friend/#{property.id}"
        test_for_speed_and_errors "/listings/sms/#{property.id}"
      end
    end

    describe "(subcommunities tests)" do
      Sub.find!(:all, :select => :token, :limit => SUBS_LIMIT, :order => "RAND()").reject { |sub| sub.token.empty? }.each do |sub|
        test_for_speed_and_errors "/communities/#{sub.token}"
        
        if articlegroup = ArticleGroup.find(:first, :select => "id, token", :conditions => {:token => sub.token })
          test_for_speed_and_errors "/communities/#{sub.token}/details"

          articlegroup.articles.find(:all, :select => :token).each do |article|
            test_for_speed_and_errors "/communities/#{sub.token}/#{article.token}"
          end
        end
          
        test_for_speed_and_errors "/listings/area/#{sub.token}"
      end
    end

    describe "(the ross report tests)" do
      ArticleGroup.find_by_token!("the_ross_report").articles.each do |article|
        test_for_speed_and_errors "/the_ross_report/#{article.token}"
      end
    end
  end
end


