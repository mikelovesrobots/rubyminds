# Often, attributes with the same names (i.e., created_at)
# are all formatted the same way.  Rather than use a
# few dozen different helper methods and "try hard" to
# format them all the same way, you can use a delegator
# and just remember one method name "for_web" which is
# used to render them all.
#
# It frees up your mind, allowing you to focus on your 
# task, formatting views.
# 
#   class Article
#     include WebDelegatorMixin
#   end
#
#   class Charge
#     include WebDelegatorMixin
#   end
#
#   # in app/views/articles/show.html.haml
#     = @article.for_web.created_at
#     => "July 18, 2008"
#
#   # in app/views/admin/charges/show.html.haml
#     = @charge.for_web.created_at
#     => "March 2, 2008"
#
# [ In retrospect, it's an interesting proof-of-concept
# that never went anywhere due to violating MVC in a pretty
# big way. - Mike ]
#
module WebDelegatorMixin
  def for_web
    @web_view_delegator ||= WebViewDelegator.new(self)
  end
end

class WebViewDelegator < SimpleDelegator
  # This seems to be the only way to get access to all
  # of the standard view helper modules
  ActionView::Base.helper_modules.each do |helper_module|
    include helper_module
  end

  def author
    escape_association :author
  end
  
  def article
    escape_association :article
  end

  def body
    markdown __getobj__.body
  end
  
  def created_at
    __getobj__.created_at.to_date.to_formatted_s(:long)
  end

  def name
    escape :name
  end
 
  def summary
    markdown __getobj__.summary
  end

  def tags
    h __getobj__.tags.collect(&:to_solr_str).to_sentence
  end

  def title
    escape :title
  end

  def version
    escape :version
  end

  protected

  def escape attribute
    h __getobj__.send(attribute)
  end

  def escape_association association
    h __getobj__.send(association).to_solr_str
  end
end
