# This is an example of one of the more readable surveys I
# created using my ruby questionnaire DSL.- Mike
class Fr60139 < Survey

  # 
  # Quotas
  #

  quota "Total Completes", 500, :hint => "Completed the survey in full"

  #
  # Exports
  #

  export_qualifier = lambda { complete? }
  export(:ruby, &export_qualifier)
  export(:xls, &export_qualifier)
  export(:verbatims, :only => :open_ends, &export_qualifier)
  
  #
  # Questions
  #

  question "intro" do
    label %{The Avery Dennison Corporation would like to gather your feedback in order to better meet the needs of consumers like yourself.  Please be assured we are not trying to sell you anything.}
    label %{The first few questions are for classification purposes.}    
  end
  
  single_answer "q1" do
    label %{To make sure that we represent all groups in our survey, please indicate which one of the following categories best describes your age.}

    radio 1, "17 or under"
    radio 2, "18 to 24"
    radio 3, "25 to 34"
    radio 4, "35 to 44"
    radio 5, "45 to 54"
    radio 6, "55 to 64"
    radio 7, "65 and over"
    
    after { skip "q1.terminate" if answers['q1'] == 1 }
  end
  
  grid "q2" do
    label %{Do you or does any member in your household work for any of the types of companies listed below?  (MARK YES OR NO FOR EACH.)}
    
    stubs = lambda do
      radio 1, "Yes"
      radio 2, "No"
    end
    
    single_attr "q2a", "An advertising agency", &stubs
    single_attr "q2b", "A public relations company", &stubs
    single_attr "q2c", "A marketing research firm or department", &stubs
    single_attr "q2d", "An office products manufacturer or retailer", &stubs
    single_attr "q2e", "A software development department or company", &stubs
    
    after do
      skip "terminate" if ('a'..'e').any? { |letter| answers["q2#{letter}"] == 1 }
    end
  end
  
  grid "q3" do
    label %{Based on your experience with Avery.com's Design & Print Online, how likely would you be to recommend Avery to a colleague or friend?  Please use this scale where "10" is "extremely likely" and "0" is "not at all likely" (MARK ONE ONLY.)}
   
    stubs = lambda do
      radio 1, "(0)<br/>Not at all Likely"
      radio 2, "(1)"
      radio 3, "(2)"
      radio 4, "(3)"
      radio 5, "(4)"
      radio 6, "(5)"
      radio 7, "(6)"
      radio 8, "(7)"
      radio 9, "(8)"                                          
      radio 10, "(9)"                                          
      radio 11, "(10)<br/>Extremely Likely"      
    end

    single_attr "q3", [nil, nil], &stubs
  end

  single_answer "q4" do
    label %{How many times have you visited Avery.com in the past six months? (MARK ONE ONLY.)}

    radio 1, "I have not visited Avery.com in the past six months."
    radio 2, "1"
    radio 3, "2"
    radio 4, "3"
    radio 5, "4"
    radio 6, "5 to 7"
    radio 7, "8 to 10"
    radio 8, "11 to 19"
    radio 9, "20 or more times"    
  end

  single_answer "q5" do
    label %{How likely are you to come back to Avery.com in the next six months?  (MARK ONE ONLY)}

    radio 1, "Very likely"
    radio 2, "Somewhat likely"
    radio 3, "Not very likely "
    radio 4, "Not at all likely"
  end

  grid "q6" do
    label %{How easy or difficult was it for you to navigate through the Avery.com website and find what you needed?  Please use this scale where "10" is "extremely easy" and "1" is "extremely difficult"  (MARK ONE ONLY.)}

    stubs = lambda do
      radio 1, "(1)<br/>Extremely Difficult"
      radio 2, "(2)"
      radio 3, "(3)"
      radio 4, "(4)"
      radio 5, "(5)"
      radio 6, "(6)"
      radio 7, "(7)"
      radio 8, "(8)"
      radio 9, "(9)"                                          
      radio 10, "(10)<br/>Extremely Easy"                                          
    end
    
    single_attr "q6", [nil,nil], &stubs
  end
  
  grid "q7" do
    label %{How many times have you personally recommended Avery to a colleague or friend in the <u>past 12 months</u>? (MARK ONE ONLY.)}
    
    stubs = lambda do
      radio 0, "0"
      radio 1, "1"
      radio 2, "2"
      radio 3, "3"
      radio 4, "4"
      radio 5, "5"
      radio 6, "6"
      radio 7, "7"
      radio 8, "8"
      radio 9, "9"                                          
      radio 10, "10 or more"                                          
    end
    
    single_attr "q7", [nil,nil], &stubs
  end
  
  single_answer "q8" do
    label %{How likely are you to come back to Design & Print Online at Avery.com in the next six months?  (MARK ONE ONLY)}

    radio 1, "Very likely"
    radio 2, "Somewhat likely"
    radio 3, "Not very likely "
    radio 4, "Not at all likely"
  end
  
  grid "q9" do
    label %{How easy or difficult was it for you to navigate through Design & Print Online and find what you needed?  Please use this scale where "10" is "extremely easy" and "1" is "extremely difficult"  (MARK ONE ONLY.)}

    stubs = lambda do
      radio 1, "(1)<br/>Extremely Difficult"
      radio 2, "(2)"
      radio 3, "(3)"
      radio 4, "(4)"
      radio 5, "(5)"
      radio 6, "(6)"
      radio 7, "(7)"
      radio 8, "(8)"
      radio 9, "(9)"                                          
      radio 10, "(10)<br/>Extremely Easy"                                          
    end
    
    single_attr "q9", [nil,nil], &stubs
  end

  question "complete" do
    before do
      complete
    end

    label %{THANK YOU FOR YOUR HELP. THAT IS ALL OF THE QUESTIONS WE HAVE.}    
  end
  
  question "q1.terminate" do
    before { terminate }
    
    label "Thank you for your interest in this survey.  Unfortunately, we have already reached our quota for people in your age group."
  end

  question "terminate" do
    before { terminate }
#    redirect "http://www.surveyspot.com/thankyou.jsp?mon=684691&stat=12"
    label %{ Thank you, that is all the questions we have today.}
  end
  
  question "overquota" do
    before { overquota }     
#    redirect "http://www.surveyspot.com/thankyou.jsp?mon=684691&stat=16"
    label %{ Thank you, that is all the questions we have today.}
  end  
end
