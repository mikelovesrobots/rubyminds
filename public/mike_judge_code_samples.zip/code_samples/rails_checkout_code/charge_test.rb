require File.dirname(__FILE__) + '/../spec_helper'
require File.dirname(__FILE__) + '/credit_card_spec'

module ChargeSpecHelper
  include CreditCardSpecHelper

  def valid_charge_attributes
    {
      :amount => 50.00,
      :credit_card => mock_model(CreditCard, valid_credit_card_attributes.with(:valid? => true))
    }
  end
end

describe Charge do
  include ChargeSpecHelper

  # Foreign key constraints are awesome, except when
  # testing with mock associations
  before(:all) do
    Charge.connection.execute("SET FOREIGN_KEY_CHECKS = 0")
  end
  
  after(:all) do
    Charge.connection.execute("SET FOREIGN_KEY_CHECKS = 1")
  end

  describe "(validations)" do
    it "should be valid with valid charge attributes" do
      charge = Charge.new(valid_charge_attributes)
      charge.valid?
      charge.remote_errors.should == {}
      charge.errors.full_messages.should == []
    end
    
    # amount
    it "should be invalid unless amount is present" do
      Charge.new(valid_charge_attributes.with(:amount => nil)).should_not be_valid
    end
    
    it "should be invalid unless amount is a number > 0" do
      Charge.new(valid_charge_attributes.with(:amount => 0)).should_not be_valid
    end
    
    # credit_card
    it "should be invalid unless credit_card is present" do
      Charge.new(valid_charge_attributes.with(:credit_card => nil)).should_not be_valid
    end

    it "should be invalid unless credit_card_id is a number > 0" do
      Charge.new(valid_charge_attributes.with(:credit_card => nil, :credit_card_id => 0)).should_not be_valid
    end
    
    it "should be invalid unless credit_card_id is an integer" do
      Charge.new(valid_charge_attributes.with(:credit_card => nil, :credit_card_id => 1.5)).should_not be_valid
    end

    # authorization_code
    it "should be invalid if authorization_code is present" do
      Charge.new(valid_charge_attributes.with(:authorization_code => "abc")).should_not be_valid
    end
  end

  describe "(ready)" do
    it "should be in a ready state by default" do
      Charge.new(valid_charge_attributes).should be_ready
    end

    it "should be valid" do
      charge = Charge.new(valid_charge_attributes)
      charge.valid?
      charge.remote_errors.should == {}
      charge.errors.full_messages.should == []
    end

    it "when initialized with an invalid credit card number, #preauthorize should be false" do
      invalid_card = mock_model(
        CreditCard, 
        valid_credit_card_attributes.with(:number => "1234567890123456", :valid? => true)
      )
      charge = Charge.new(valid_charge_attributes.with(:credit_card => invalid_card))
      charge.preauthorize.should be_false
    end

    it "when initialized with an invalid credit card number, and called #preauthorize, should not be valid" do
      invalid_card = mock_model(
        CreditCard, 
        valid_credit_card_attributes.with(:number => "1234567890123456", :valid? => true)
      )
      charge = Charge.new(valid_charge_attributes.with(:credit_card => invalid_card))
      charge.preauthorize
      charge.should_not be_valid
    end

    it "when created with an invalid card number, and called #preauthorize, should still be ready" do 
      invalid_card = mock_model(
        CreditCard, 
        valid_credit_card_attributes.with(:number => "1234567890123456", :valid? => true)
      )
      charge = Charge.new(valid_charge_attributes.with(:credit_card => invalid_card))
      charge.preauthorize
      charge.should be_ready
    end

    it "when initialized with a valid credit card number, #preauthorize should be true" do
      Charge.new(valid_charge_attributes).preauthorize.should be_true
    end

    it "when initialized with a valid credit card number, and called #preauthorize, should be valid" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.should be_valid
    end

    it "when created with a valid card number, and called #preauthorize, should be authorized" do 
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.should be_authorized
    end
  end

  describe "(authorized)" do
    it "should be valid" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.valid?
      charge.remote_errors.should == {}
      charge.errors.full_messages.should == []
    end

    it "should have an authorization code" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.authorization_code.should_not be_empty
    end

    it "should be voidable" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.void
      charge.should be_voided
    end

    it "when the amount hasn't changed, should be capturable" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.capture
      charge.should be_charged
    end
  end

  describe "(captured)" do
    it "should be valid" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.capture
      charge.valid?
      charge.remote_errors.should == {}
      charge.errors.full_messages.should == []
    end
  end

  describe "(charged)" do
    it "when initialized with a valid credit card number, and called #purchase, should be valid" do
      charge = Charge.new(valid_charge_attributes)
      charge.purchase
      charge.valid?
      charge.remote_errors.should == {}
      charge.errors.full_messages.should == []
    end
    
    it "when initialized with a valid credit card number, and called #purchase, should be charged" do
      charge = Charge.new(valid_charge_attributes)
      charge.purchase
      charge.should be_charged
    end
    
    it "when initialized with a valid credit card number, and called #purchase, should set authorization_code" do
      charge = Charge.new(valid_charge_attributes)
      charge.purchase
      charge.authorization_code.should_not be_blank
    end
    
    it "when initialized with an invalid credit card number, and called #purchase, should not be valid" do
      invalid_card = mock_model(
        CreditCard, 
        valid_credit_card_attributes.with(:number => "1234567890123456", :valid? => true)
      )

      charge = Charge.new(valid_charge_attributes.with(:credit_card => invalid_card))
      charge.purchase
      charge.should_not be_valid
    end

    it "when initialized with an invalid credit card number, and called #purchase, should not be charged" do
      invalid_card = mock_model(
        CreditCard, 
        valid_credit_card_attributes.with(:number => "1234567890123456", :valid? => true)
      )

      charge = Charge.new(valid_charge_attributes.with(:credit_card => invalid_card))
      charge.purchase
      charge.should_not be_charged
    end
  end

  describe "(voided)" do
    it "should be valid" do
      charge = Charge.new(valid_charge_attributes)
      charge.preauthorize
      charge.void
      charge.valid?
      charge.remote_errors.should == {}
      charge.errors.full_messages.should == []
    end
  end
end

