# == Schema Information
# Schema version: 119
#
# Table name: charges
#
#  id                 :integer(11)     not null, primary key
#  amount             :decimal(8, 2)   not null
#  state              :enum(authorized default(:ready), not null
#  authorization_code :string(255)     
#  credit_card_id     :integer(11)     not null
#  created_at         :datetime        
#  updated_at         :datetime        
#

class Charge < ActiveRecord::Base

  solr_powered

  ##
  ## Validations
  ##

  validates_numericality_of :amount, :greater_than => 0
  validates_length_of :authorization_code, :maximum => 255, :unless => :ready?
  validates_length_of :authorization_code, :allow_blank => true, :is => 0, :if => :ready?
  validates_numericality_of :credit_card_id, :greater_than => 0, :only_integer => true
  validate :validate_remote_errors

  ##
  ## Associations
  ##

  belongs_to :credit_card
  has_many :carts
  
  ##
  ## Accessors
  ##

  # Returns the current amount in cents, useful for all the paypal gateway_* methods
  def amount_in_cents
    amount * 100
  end
  
  ##
  ## State machine / charge interface
  ##

  #
  #    (initial state)
  #         READY  ----- #purchase --->  CHARGED
  #           |                            / \
  #     #preauthorize                       |
  #           |                             |
  #          \ /                            |
  #       AUTHORIZED ---- #capture ---------/
  #           |
  #         #void
  #           |
  #          \ /
  #         VOIDED
  #
  
  acts_as_state_machine :initial => :ready

  state :ready
  state :authorized
  state :voided
  state :charged

  # Charges the user's credit card.  Transitioning from the default :ready state
  # to the :charged state if the purchase was successful.
  #
  #   charge = Charge.new(:amount => 10.00, :credit_card => my_credit_card)
  #   if charge.purchase
  #     charge.save
  #   else
  #     charge.remote_errors.each { |k,v| my_credit_card.errors.add(k,v) }
  #     ...
  #   end
  #
  event :purchase do
    transitions :from => :ready, :to => :charged, :guard => :gateway_purchase
  end

  # Preauthorizes a charge on the user's credit card.  Transitioning from the
  # default :ready state to the :authorized state if the purchase was successful.
  #
  # NOTE:  This puts a hold on the funds for 30 days, so make sure you follow
  # up with a #capture -- or release the preauthorization with a #void --
  # or you're going to screw up their finances something fierce.
  #
  #   charge = Charge.new(:amount => 10.00, :credit_card => my_credit_card)
  #   if charge.preauthorize
  #     charge.save
  #   else
  #     charge.remote_errors.each { |k,v| my_credit_card.errors.add(k,v) }
  #     ...
  #
  #   # a later capture
  #
  #   charge = Charge.find(...)
  #   if charge.capture
  #     charge.save
  #   else
  #     charge.remote_errors.each { |k,v| my_credit_card.errors.add(k,v) }
  #     ...
  #   end
  #
  #   # alternately, a later void
  #
  #   charge = Charge.find(...)
  #   if charge.void
  #     charge.save
  #   else
  #     charge.remote_errors.each { |k,v| my_credit_card.errors.add(k,v) }
  #     ...
  #   end
  #
  event :preauthorize do
    transitions :from => :ready, :to => :authorized, :guard => :gateway_preauthorize
  end

  # Converts a preauthorization into a charge.  Transitions from the :authorized
  # state into the :charged state if successful.
  #
  #   charge = Charge.new(:amount => 10.00, :credit_card => my_credit_card)
  #   if charge.preauthorize and charge.capture
  #     charge.save    
  #     ...
  #   else
  #     charge.remote_errors.each { |k,v| my_credit_card.errors.add(k,v) }
  #     ...
  #   end
  #
  event :capture do
    transitions :from => :authorized, :to => :charged, :guard => :gateway_capture
  end

  # Voids a preauthorization, releasing held funds.  Transitions from the :authorized
  # state to the :voided state.
  #
  #   charge = Charge.new(:amount => 10.00, :credit_card => my_credit_card)
  #   if charge.preauthorize and charge.void
  #     charge.save    
  #   else
  #     charge.remote_errors.each { |k,v| my_credit_card.errors.add(k,v) }
  #     ...
  #   end
  #
  event :void do
    transitions :from => :authorized, :to => :voided, :guard => :gateway_void
  end

  ##
  ## Methods
  ##

  public

  # Returns a collection of errors collected from the remote payment gateway
  def remote_errors
    @remote_errors ||= {}
  end

  protected

  # If a charge was previously pre-authorized, calling gateway_capture will charge that
  # amount to the credit card.
  #
  # Used internally, see #capture event
  # See #gateway for values returned, errors raised, and other side effects
  #
  def gateway_capture
    gateway(:capture, amount_in_cents, authorization_code)
  end

  # Attempts to pre-authorize payment.
  #
  # Used internally, see #preauthorize event
  # See #gateway for values returned, errors raised, and other side effects
  #
  def gateway_preauthorize
    gateway_preauthorize_or_purchase(:authorize)
  end

  # Attempts to make the purchase.
  #
  # Used internally, see #purchase event
  # See #gateway for values returned, errors raised, and other side effects
  #
  def gateway_purchase
    gateway_preauthorize_or_purchase(:purchase)
  end

  # Attempts to pre-authorize or make a purchase
  #
  # Used internally, see #preauthorize or #purchase
  # See #gateway for values returned, errors raised, and other side effects
  #
  def gateway_preauthorize_or_purchase(message)
    self.authorization_code = ''
    save! if new_record? # need the id to create the order_id

    gateway(
      message, 
      amount_in_cents,
      credit_card, 
      :ip => credit_card.ip,
      :order_id => "#{id}-#{created_at.to_i}",
      :description => '',
      :billing_address => {
        :address1 => credit_card.address1,
        :address2 => credit_card.address2,
        :city => credit_card.city,
        :state => credit_card.state,
        :zip => credit_card.zip,
        :country => credit_card.country,
      }
    )
  end

  # This will void a preauthorization, releasing the held funds.
  #
  # Used internally, see #void
  # See #gateway for values returned, errors raised, and other side effects
  #
  def gateway_void
    gateway(:void, authorization_code)
  end

  #
  # Encapsulates setup and teardown for communicating with the paypal gateway.
  #
  # On success
  #   sets authorization_code to the value returned by the gateway
  #   returns true
  #
  # On invalid object
  #   returns false
  #
  # On failure
  #   inserts errors into #remote_errors. (e.g., :credit_card => "is not valid")
  #   returns false
  #
  # @raises
  #   PaypalGatewayError on an unrecoverable Paypal error (e.g., bad API credentials, SocketError)
  #
  def gateway(message, *args)
    return false unless valid?

    response = paypal_gateway.send(message, *args)

    if response.success?
      remote_errors.clear
      self.authorization_code = response.authorization
    else
      remote_errors.replace(PAYPAL_ERRORS[response.params['error_codes'].to_i] || {:system => "unknown response"})

      if remote_errors[:system]
        raise PaypalGatewayError, response.params.inspect
      end

      validate_remote_errors
    end

    response.success?
  rescue SocketError => e
    # Usually means that the network connection went down
    raise PaypalGatewayError, e.message
  end

  # Returns true if this model has no remote errors, otherwise, sets an
  # error on base and returns false.
  def validate_remote_errors
    errors.add_to_base("has remote errors") unless remote_errors.empty?
  end

  # Should encapsulate and initialize the paypal gateway
  def paypal_gateway
    @gateway ||= if RAILS_ENV == "production" 
                   ActiveMerchant::Billing::PaypalGateway.new(
                     :login => Cfg.paypal.production.login,
                     :password => Cfg.paypal.production.password,
                     :signature => Cfg.paypal.production.signature
                   )
                 else
                   # Tell ActiveMerchant that we're in test mode
                   ActiveMerchant::Billing::Base.gateway_mode = :test

                   # Testing credentials
                   ActiveMerchant::Billing::PaypalGateway.new(
                     :login => Cfg.paypal.test.login,
                     :password => Cfg.paypal.test.password,
                     :signature => Cfg.paypal.test.signature
                   )
                 end
  end

  ## 
  ## Utility Methods
  ##

  public
  def to_solr_str
    state
  end
end

class PaypalGatewayError < Exception
end
